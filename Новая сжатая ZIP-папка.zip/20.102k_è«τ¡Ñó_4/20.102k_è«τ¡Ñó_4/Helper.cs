﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20._102k_Кочнев_4
{
    class Helper
    {
        private static Entity.Entities entities;

        public static Entity.Entities GetContext()
        {
            if (entities == null)
            {
                entities = new Entity.Entities();
            }
            return entities;
        }
    }
}